iPhone 5 Mockup

Thank downloaded file! =)

- PSD file (Photoshop CS6) (Compatible with CS5)
- High resolution image 2480X2480
- 300dpi
- Professional and clean design
- Fully customizable shapes

Step-by-step instructions:
1) Select and Copy your vector or bitmap artwork from your design application into the desired Smart Object layer by double clicking it.
2) Add additional artwork layers or make customizations to the object image shadows or background.
3) Print and/or save the final image.

