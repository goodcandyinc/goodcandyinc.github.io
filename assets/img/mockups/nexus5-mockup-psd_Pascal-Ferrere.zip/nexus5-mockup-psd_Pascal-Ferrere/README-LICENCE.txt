NEXUS 5 FREE PSD MOCKUP

Version: 1.0

Creation Date: 11/06/2014
Last Modification: --/--/--



CONTACT INFORMATION

Contact: Pascal Ferrere
website: http://www.iampascal.me
Twitter: https://twitter.com/pascalferrere
Dribble: https://dribbble.com/pascalferrere
Behance: https://www.behance.net/pascalferrere
Linkedin: https://www.linkedin.com/in/pascalferrere


LICENCE TERMS

This ressource is free for personal and commercial use. 
You can freely modify the file but I cannot be liable in the case of a misuse of this resource.

You can share and distribute this resource to any other website but with a single condition ; to link back the resource to: http://www.iampascal.me
You are not allowed to sell, resell, lease, redistribute, sub-license or offer this resource to any third party, with the aim to make financial profits.

Spreading the word about this resource on the social networks is not an obligation but would be really appreciated.

Thank you for downloading. 